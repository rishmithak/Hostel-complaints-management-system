-- MySQL dump 10.13  Distrib 5.7.33, for Win64 (x86_64)
--
-- Host: localhost    Database: HCMS
-- ------------------------------------------------------
-- Server version	5.7.33-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `complaint`
--

DROP TABLE IF EXISTS `complaint`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `complaint` (
  `C_ID` int(11) NOT NULL AUTO_INCREMENT,
  `C_Date` datetime DEFAULT NULL,
  `C_Nature` varchar(2000) DEFAULT NULL,
  `SNU_ID` int(11) DEFAULT NULL,
  `C_Status` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`C_ID`),
  KEY `SNU_ID` (`SNU_ID`),
  CONSTRAINT `complaint_ibfk_1` FOREIGN KEY (`SNU_ID`) REFERENCES `student` (`SNU_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `complaint`
--

LOCK TABLES `complaint` WRITE;
/*!40000 ALTER TABLE `complaint` DISABLE KEYS */;
INSERT INTO `complaint` VALUES (2,'2021-04-16 22:52:54','plumber',18004,'resolved'),(3,'2021-04-16 22:53:04','plumber',18004,'resolved'),(4,'2021-04-16 22:54:38','bell not working',18004,'resolved'),(5,'2021-04-16 22:59:00','ac not working',18004,'resolved'),(6,'2021-04-16 23:02:56','light fuse',18004,'resolved'),(7,'2021-04-16 23:07:49','noise',18004,'resolved'),(9,'2021-04-17 10:01:32','help',18004,'resolved'),(10,'2021-04-17 11:39:21','water flood',18004,'resolved'),(11,'2021-04-17 11:40:27','fused lights',18001,'resolved'),(12,'2021-04-17 11:47:01','help',18004,'ongoing'),(13,'2021-04-18 15:51:37','faucet leaking',18001,'ongoing');
/*!40000 ALTER TABLE `complaint` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER New_Complaint
BEFORE INSERT ON Complaint FOR EACH ROW
BEGIN
SET NEW.C_Date = NOW();
SET NEW.C_Status = "ongoing";
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `rooms_allowed`
--

DROP TABLE IF EXISTS `rooms_allowed`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rooms_allowed` (
  `R_NO` int(11) NOT NULL,
  PRIMARY KEY (`R_NO`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rooms_allowed`
--

LOCK TABLES `rooms_allowed` WRITE;
/*!40000 ALTER TABLE `rooms_allowed` DISABLE KEYS */;
INSERT INTO `rooms_allowed` VALUES (11),(12),(13),(14),(15),(16),(21),(22),(23),(24),(25),(26),(31),(32),(33),(34),(35),(36),(41),(42),(43),(44),(45),(46),(51),(52),(53),(54),(55),(56),(61),(62),(63),(64),(65),(66);
/*!40000 ALTER TABLE `rooms_allowed` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `student`
--

DROP TABLE IF EXISTS `student`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `student` (
  `SNU_ID` int(11) NOT NULL,
  `Name` varchar(30) DEFAULT NULL,
  `Year` int(11) DEFAULT NULL,
  `Room_No` int(11) DEFAULT NULL,
  `Tower_no` int(11) DEFAULT NULL,
  `password` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`SNU_ID`),
  KEY `Room_No` (`Room_No`),
  KEY `Tower_no` (`Tower_no`),
  CONSTRAINT `student_ibfk_1` FOREIGN KEY (`Room_No`) REFERENCES `rooms_allowed` (`R_NO`),
  CONSTRAINT `student_ibfk_2` FOREIGN KEY (`Tower_no`) REFERENCES `towers` (`T_NO`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student`
--

LOCK TABLES `student` WRITE;
/*!40000 ALTER TABLE `student` DISABLE KEYS */;
INSERT INTO `student` VALUES (18001,'Pihu Ved',2,11,2,'12345'),(18002,'Lakshita Kumar',2,11,2,'12345'),(18003,'Janvi Singh',2,11,2,NULL),(18004,'Ahalya',2,11,2,'12345'),(18005,'Maitreyi Upreti ',2,11,2,NULL),(18006,'Akshita Agarwal',2,12,2,NULL),(18007,'Riya Rastogi',2,12,2,NULL),(18008,'Sana Dawood',2,12,2,NULL),(18009,'Rashiqa Naqvi',2,12,2,NULL),(18010,'Soumya Chilikamarri',2,12,2,NULL),(18011,'Sreya Parthasarthy',2,13,2,NULL),(18012,'Kishika Sharath',2,13,2,NULL),(18013,'Reet Arora',2,13,2,NULL),(18014,'Vedika Kumar',2,13,2,NULL),(18015,'Vernika Pradhan',2,13,2,NULL),(19001,'Vrinda Shukla',1,11,9,NULL),(19002,'Vartika Kumar',1,11,9,NULL),(19003,'Smriti Ranjan',1,11,9,NULL),(19004,'Chhaaya Chopra',1,11,9,NULL),(19005,'Payal Awasthi',1,11,9,NULL),(19006,'Pranati Kashyap',1,12,9,NULL),(19007,'Kasturi Methi',1,12,9,NULL),(19008,'Ria Narang',1,12,9,NULL),(19009,'Asmi Chawla',1,12,9,NULL),(19010,'Khushi Mishra',1,12,9,NULL),(19011,'Kanishka Pathak',1,13,9,NULL),(19012,'Riya Chaturvedi',1,13,9,NULL),(19013,'Amaya Trivedi ',1,13,9,NULL),(19014,'Stuti Dwivedi ',1,13,9,NULL);
/*!40000 ALTER TABLE `student` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `towers`
--

DROP TABLE IF EXISTS `towers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `towers` (
  `T_NO` int(11) NOT NULL,
  PRIMARY KEY (`T_NO`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `towers`
--

LOCK TABLES `towers` WRITE;
/*!40000 ALTER TABLE `towers` DISABLE KEYS */;
INSERT INTO `towers` VALUES (2),(9);
/*!40000 ALTER TABLE `towers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `warden_passwords`
--

DROP TABLE IF EXISTS `warden_passwords`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `warden_passwords` (
  `EMP_ID` int(11) NOT NULL,
  `PASSWORD` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`EMP_ID`),
  CONSTRAINT `warden_passwords_ibfk_1` FOREIGN KEY (`EMP_ID`) REFERENCES `wardens` (`EMP_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `warden_passwords`
--

LOCK TABLES `warden_passwords` WRITE;
/*!40000 ALTER TABLE `warden_passwords` DISABLE KEYS */;
INSERT INTO `warden_passwords` VALUES (11011,'admin'),(11022,'admin');
/*!40000 ALTER TABLE `warden_passwords` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wardens`
--

DROP TABLE IF EXISTS `wardens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wardens` (
  `EMP_ID` int(11) NOT NULL,
  `NAME` varchar(30) DEFAULT NULL,
  `T_NO` int(11) DEFAULT NULL,
  PRIMARY KEY (`EMP_ID`),
  KEY `T_NO` (`T_NO`),
  CONSTRAINT `wardens_ibfk_1` FOREIGN KEY (`T_NO`) REFERENCES `towers` (`T_NO`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wardens`
--

LOCK TABLES `wardens` WRITE;
/*!40000 ALTER TABLE `wardens` DISABLE KEYS */;
INSERT INTO `wardens` VALUES (11011,'Ritu Taneja',2),(11022,'Meena Kumari',9);
/*!40000 ALTER TABLE `wardens` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-04-20 11:38:13
