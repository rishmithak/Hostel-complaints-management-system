package frames;


public class FXMLMenuController 
{
    
}
